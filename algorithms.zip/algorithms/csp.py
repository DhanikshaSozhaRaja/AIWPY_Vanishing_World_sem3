"""Constraint Satisfaction Problem (CSP + AC-3 + Backtracking) solver for Vanishing World."""

from __future__ import annotations

from collections import deque
from typing import Callable, Dict, FrozenSet, List, Optional, Set, Tuple

from algorithms.common import Position, SearchLimitReached, get_env

ConstraintFn = Callable[[int, Position, int, Position], bool]


class CSP:
    def __init__(
        self,
        domains: Dict[int, Set[Position]],
        neighbors: Dict[int, Set[int]],
        constraint: ConstraintFn,
    ) -> None:
        self.domains: Dict[int, Set[Position]] = {k: set(v) for k, v in domains.items()}
        self.neighbors: Dict[int, Set[int]] = {k: set(v) for k, v in neighbors.items()}
        self.constraint = constraint

    def revise(self, domains: Dict[int, Set[Position]], xi: int, xj: int) -> bool:
        supported: Set[Position] = set()
        dom_i = domains[xi]
        dom_j = domains[xj]

        for x in dom_i:
            if any(self.constraint(xi, x, xj, y) for y in dom_j):
                supported.add(x)

        if len(supported) != len(dom_i):
            domains[xi] = supported
            return True
        return False

    def ac3(
        self,
        domains: Dict[int, Set[Position]],
        initial_queue: Optional[List[Tuple[int, int]]] = None,
    ) -> bool:
        queue = deque(
            initial_queue
            if initial_queue is not None
            else [(xi, xj) for xi, nbs in self.neighbors.items() for xj in nbs]
        )

        while queue:
            xi, xj = queue.popleft()
            if self.revise(domains, xi, xj):
                if not domains[xi]:
                    return False
                for xk in self.neighbors[xi]:
                    if xk != xj:
                        queue.append((xk, xi))
        return True

    def backtrack(
        self,
        domains: Dict[int, Set[Position]],
        crystals: FrozenSet[Position],
        attempts: List[int],
        max_nodes: Optional[int],
        req_keys: FrozenSet[Position],
        req_gates: Set[Position],
    ) -> Optional[Dict[int, Position]]:
        if all(len(vals) == 1 for vals in domains.values()):
            assignment = {var: next(iter(vals)) for var, vals in domains.items()}
            assigned_vals = set(assignment.values())
            if not crystals.issubset(assigned_vals):
                return None

            if req_keys and req_gates:
                val_to_step = {pos: step for step, pos in assignment.items()}
                gate_steps = [val_to_step[g] for g in req_gates if g in val_to_step]
                if gate_steps:
                    min_gate_step = min(gate_steps)
                    for rk in req_keys:
                        k_step = val_to_step.get(rk)
                        if k_step is None or k_step >= min_gate_step:
                            return None
            return assignment

        possible_positions: Set[Position] = set()
        for vals in domains.values():
            possible_positions.update(vals)
        if not crystals.issubset(possible_positions):
            return None

        if req_keys and req_gates:
            for step, vals in domains.items():
                if len(vals) == 1:
                    only_val = next(iter(vals))
                    if only_val in req_gates:
                        for rk in req_keys:
                            if not any(rk in domains.get(s, ()) for s in range(step)):
                                return None

        unassigned = [v for v, vals in domains.items() if len(vals) > 1]
        if not unassigned:
            return None
        chosen_var = min(unassigned, key=lambda v: len(domains[v]))

        for value in sorted(domains[chosen_var]):
            attempts[0] += 1
            if max_nodes is not None and attempts[0] > max_nodes:
                raise SearchLimitReached(attempts[0] - 1)

            new_domains = {k: set(v) for k, v in domains.items()}
            new_domains[chosen_var] = {value}

            if self.ac3(new_domains):
                result = self.backtrack(
                    new_domains, crystals, attempts, max_nodes, req_keys, req_gates
                )
                if result is not None:
                    return result

        return None


def _build_csp(start_state: object, path_length: int) -> Optional[CSP]:
    env = get_env()
    walkable: Set[Position] = {
        (r, c)
        for r in range(env.ROWS)
        for c in range(env.COLS)
        if (r, c) not in env.WALLS and (r, c) not in start_state.vanished  # type: ignore[attr-defined]
    }

    if start_state.player not in walkable or env.EXIT_TILE not in walkable:  # type: ignore[attr-defined]
        return None

    domains: Dict[int, Set[Position]] = {}
    base_step = len(start_state.vanished)  # type: ignore[attr-defined]
    for i in range(path_length + 1):
        dom = set(walkable)
        if start_state.keys and i <= len(start_state.keys):  # type: ignore[attr-defined]
            dom.difference_update(env.LOCKED_GATES)
        if i > 0:
            step_num = base_step + i
            if env.CRUMBLING_TILES:
                dom = {
                    p
                    for p in dom
                    if p not in env.CRUMBLING_TILES or step_num <= env.CRUMBLING_TILES[p]
                }
            if env.SPIKE_TILES:
                dom = {
                    p
                    for p in dom
                    if p not in env.SPIKE_TILES or env.SPIKE_TILES[p] != (step_num % 2)
                }
        domains[i] = dom
    domains[0] = {start_state.player}  # type: ignore[attr-defined]
    domains[path_length] = {env.EXIT_TILE}

    neighbors: Dict[int, Set[int]] = {
        i: {j for j in range(path_length + 1) if j != i}
        for i in range(path_length + 1)
    }

    one_way = env.ONE_WAY_TILES
    directions = env.DIRECTIONS

    def constraint(xi: int, x: Position, xj: int, y: Position) -> bool:
        if xi != xj and x == y:
            return False
        if xj == xi + 1:
            forced = one_way.get(x)
            if forced:
                dr, dc = directions[forced]
                return y == (x[0] + dr, x[1] + dc)
            return abs(x[0] - y[0]) + abs(x[1] - y[1]) == 1
        if xi == xj + 1:
            forced = one_way.get(y)
            if forced:
                dr, dc = directions[forced]
                return x == (y[0] + dr, y[1] + dc)
            return abs(x[0] - y[0]) + abs(x[1] - y[1]) == 1
        return True

    return CSP(domains, neighbors, constraint)


def csp_search(
    start_state: Optional[object] = None, max_nodes: Optional[int] = 100000
) -> Tuple[Optional[List[str]], int]:
    env = get_env()
    initial = start_state if start_state is not None else env.create_initial_state()
    if initial.status != "playing":
        return None, 0

    available = env.ROWS * env.COLS - len(env.WALLS) - len(initial.vanished)
    if available <= 1:
        return None, 0

    max_allowed = env.MAX_MOVES - len(initial.vanished) if env.MAX_MOVES > 0 else available - 1
    max_path_length = min(available - 1, max_allowed)
    min_moves = max(1, len(initial.crystals) + 1)
    attempts = [0]

    for path_len in range(min_moves, max_path_length + 1):
        csp = _build_csp(initial, path_len)
        if csp is None:
            continue

        domains = {k: set(v) for k, v in csp.domains.items()}
        if not csp.ac3(domains):
            continue

        assignment = csp.backtrack(
            domains,
            initial.crystals,
            attempts,
            max_nodes,
            initial.keys,
            env.LOCKED_GATES,
        )
        if assignment is None:
            continue

        positions = [assignment[i] for i in range(path_len + 1)]
        directions: List[str] = []
        valid = True

        for i in range(len(positions) - 1):
            cur, dst = positions[i], positions[i + 1]
            diff = (dst[0] - cur[0], dst[1] - cur[1])
            matched = next(
                (name for name, vec in env.DIRECTIONS.items() if vec == diff), None
            )
            if matched is None:
                valid = False
                break
            directions.append(matched)

        if not valid:
            continue

        sim_state = initial
        for d in directions:
            sim_state = env.move_state(sim_state, d)
            if sim_state is None or sim_state.status == "lost":
                valid = False
                break

        if valid and sim_state is not None and env.is_goal_state(sim_state):
            return directions, attempts[0]

    return None, attempts[0]
