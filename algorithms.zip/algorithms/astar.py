"""A* Search solver for Vanishing World."""

from __future__ import annotations

import heapq
from typing import Dict, List, Optional, Tuple

from algorithms.common import Direction, Position, check_limit, get_env, reconstruct_path


def astar_heuristic(state: object) -> int:
    env = get_env()
    targets: List[Position] = list(state.crystals) + [env.EXIT_TILE]  # type: ignore[attr-defined]
    return max(
        (env.manhattan_distance(state.player, t) for t in targets),  # type: ignore[attr-defined]
        default=0,
    )


def astar_search(
    start_state: Optional[object] = None, max_nodes: Optional[int] = None
) -> Tuple[Optional[List[Direction]], int]:
    env = get_env()
    initial = start_state if start_state is not None else env.create_initial_state()
    counter = 0
    pq: List[Tuple[int, int, int, object]] = [
        (astar_heuristic(initial), counter, 0, initial)
    ]
    g_score: Dict[object, int] = {initial: 0}
    parent: Dict[object, Optional[Tuple[object, Direction]]] = {initial: None}
    nodes_explored = 0

    while pq:
        _, _, cur_g, current = heapq.heappop(pq)
        if cur_g != g_score.get(current):
            continue

        nodes_explored += 1
        if env.is_goal_state(current):
            return reconstruct_path(current, parent), nodes_explored

        check_limit(nodes_explored, max_nodes)
        if current.status == "lost":  # type: ignore[attr-defined]
            continue

        for direction in env.get_legal_moves(current):
            nxt = env.move_state(current, direction)
            if nxt is None or nxt.status == "lost":
                continue
            new_g = cur_g + 1
            if new_g < g_score.get(nxt, float("inf")):  # type: ignore[operator]
                g_score[nxt] = new_g
                parent[nxt] = (current, direction)
                counter += 1
                f = new_g + astar_heuristic(nxt)
                heapq.heappush(pq, (f, counter, new_g, nxt))

    return None, nodes_explored
