"""Depth-First Search (DFS) solver for Vanishing World."""

from __future__ import annotations

from typing import Dict, List, Optional, Set, Tuple

from algorithms.common import Direction, check_limit, get_env, reconstruct_path


def dfs_search(
    start_state: Optional[object] = None, max_nodes: Optional[int] = None
) -> Tuple[Optional[List[Direction]], int]:
    env = get_env()
    initial = start_state if start_state is not None else env.create_initial_state()
    stack: List[object] = [initial]
    visited: Set[object] = {initial}
    parent: Dict[object, Optional[Tuple[object, Direction]]] = {initial: None}
    nodes_explored = 0

    while stack:
        current = stack.pop()
        nodes_explored += 1

        if env.is_goal_state(current):
            return reconstruct_path(current, parent), nodes_explored

        check_limit(nodes_explored, max_nodes)
        if current.status == "lost":  # type: ignore[attr-defined]
            continue

        for direction in env.get_legal_moves(current):
            nxt = env.move_state(current, direction)
            if nxt is None or nxt in visited or nxt.status == "lost":
                continue
            visited.add(nxt)
            parent[nxt] = (current, direction)
            stack.append(nxt)

    return None, nodes_explored
