"""Shared search utilities and active game environment bridge."""

from __future__ import annotations

import sys
from types import ModuleType
from typing import Callable, Dict, List, Optional, Tuple

Position = Tuple[int, int]
Direction = str
SearchFn = Callable[[Optional[object], Optional[int]], Tuple[Optional[List[Direction]], int]]

_GAME_ENV: Optional[ModuleType] = None


class SearchLimitReached(Exception):
    def __init__(self, nodes_explored: int) -> None:
        super().__init__("Search node limit reached")
        self.nodes_explored = nodes_explored


def register_game_env(module: ModuleType) -> None:
    global _GAME_ENV
    _GAME_ENV = module


def get_env() -> ModuleType:
    if _GAME_ENV is not None:
        return _GAME_ENV
    mod = sys.modules.get("main") or sys.modules.get("__main__")
    if mod is None:
        raise RuntimeError("Game environment is not registered yet.")
    return mod


def check_limit(nodes_explored: int, max_nodes: Optional[int]) -> None:
    if max_nodes is not None and nodes_explored >= max_nodes:
        raise SearchLimitReached(nodes_explored)


def reconstruct_path(
    goal_state: object,
    parent: Dict[object, Optional[Tuple[object, Direction]]],
) -> List[Direction]:
    path: List[Direction] = []
    cur = goal_state
    while True:
        entry = parent.get(cur)
        if entry is None:
            break
        prev_state, direction = entry
        path.append(direction)
        cur = prev_state
    path.reverse()
    return path
