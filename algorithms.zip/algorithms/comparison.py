"""Algorithm benchmarking, caching, and comparison suite for Vanishing World."""

from __future__ import annotations

import time
from typing import Dict, List, Optional, Tuple

from algorithms.astar import astar_search
from algorithms.bfs import bfs_search
from algorithms.common import Direction, SearchFn, SearchLimitReached, get_env
from algorithms.csp import csp_search
from algorithms.dfs import dfs_search
from algorithms.greedy import greedy_search
from algorithms.iddfs import iddfs_search

_SEARCH_RESULT_CACHE: Dict[str, Dict[str, object]] = {}


def clear_search_result_cache() -> None:
    _SEARCH_RESULT_CACHE.clear()


def record_search_result(
    raw_name: str,
    solution: Optional[List[Direction]],
    nodes: Optional[int],
    elapsed_ms: float,
    status: Optional[str] = None,
) -> None:
    aliases = {
        "Greedy": "Greedy Best-First",
        "Greedy Best First": "Greedy Best-First",
        "A* Search": "A*",
    }
    name = aliases.get(raw_name, raw_name)
    final_status = status or ("Completed" if solution is not None else "No solution found")
    _SEARCH_RESULT_CACHE[name] = {
        "name": name,
        "moves": len(solution) if solution is not None else None,
        "nodes": nodes,
        "time": elapsed_ms,
        "path": " -> ".join(solution) if solution is not None else final_status,
        "status": final_status,
        "source": "Previously recorded AI run",
    }


def get_search_node_budget(search_name: str = "A*") -> int:
    env = get_env()
    size = max(env.ROWS, env.COLS)
    if size <= 5:
        return 100000
    if size <= 7:
        return 30000
    if size <= 9:
        return 10000 if search_name in ("A*", "Greedy", "CSP + AC-3") else 5000
    return 5000 if search_name in ("A*", "Greedy", "CSP + AC-3") else 2000


def get_comparison_plan(
    rows: int, cols: int
) -> Dict[str, Optional[Tuple[SearchFn, int]]]:
    size = max(rows, cols)
    if size <= 5:
        return {
            "BFS": (bfs_search, 100000),
            "DFS": (dfs_search, 10000),
            "IDDFS": (iddfs_search, 100000),
            "Greedy Best-First": (greedy_search, 10000),
            "A*": (astar_search, 10000),
            "CSP + AC-3": (csp_search, 100000),
        }
    if size <= 7:
        return {
            "BFS": (bfs_search, 5000),
            "DFS": (dfs_search, 5000),
            "IDDFS": (iddfs_search, 5000),
            "Greedy Best-First": (greedy_search, 10000),
            "A*": (astar_search, 10000),
            "CSP + AC-3": (csp_search, 100000),
        }
    return {
        "BFS": None,
        "DFS": (dfs_search, 3000),
        "IDDFS": None,
        "Greedy Best-First": (greedy_search, 5000),
        "A*": (astar_search, 5000),
        "CSP + AC-3": (csp_search, 50000),
    }


def compare_algorithms(start_state: Optional[object] = None) -> List[Dict[str, object]]:
    env = get_env()
    initial = start_state if start_state is not None else env.create_initial_state()
    plan = get_comparison_plan(env.ROWS, env.COLS)
    results: List[Dict[str, object]] = []

    for name, algo_plan in plan.items():
        cached = _SEARCH_RESULT_CACHE.get(name)
        if cached is not None:
            results.append(dict(cached))
            continue

        if algo_plan is None:
            results.append(
                {
                    "name": name,
                    "moves": None,
                    "nodes": None,
                    "time": None,
                    "path": "Not run for this board size",
                    "status": "Skipped — board too large for default comparison",
                    "source": "Not run",
                }
            )
            continue

        search_fn, node_limit = algo_plan
        t0 = time.perf_counter()
        solution: Optional[List[Direction]] = None
        nodes_explored: Optional[int] = None
        status = "Not completed"

        try:
            solution, nodes_explored = search_fn(initial, node_limit)
            status = "Completed" if solution is not None else "No solution found"
        except SearchLimitReached as err:
            nodes_explored = err.nodes_explored
            status = "Stopped — search limit reached"

        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        results.append(
            {
                "name": name,
                "moves": len(solution) if solution is not None else None,
                "nodes": nodes_explored,
                "time": elapsed_ms,
                "path": " -> ".join(solution) if solution is not None else status,
                "status": status,
                "source": "Measured during comparison",
            }
        )

    return results
