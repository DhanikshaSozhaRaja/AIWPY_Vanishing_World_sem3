"""Greedy Best-First Search solver for Vanishing World."""

from __future__ import annotations

import heapq
from typing import Dict, List, Optional, Set, Tuple

from algorithms.common import Direction, Position, check_limit, get_env, reconstruct_path


def greedy_heuristic(state: object) -> int:
    env = get_env()
    need_key = len(state.keys) > 0 and len(env.LOCKED_GATES) > 0  # type: ignore[attr-defined]
    if len(state.crystals) == 0 and not need_key:  # type: ignore[attr-defined]
        return env.manhattan_distance(state.player, env.EXIT_TILE)  # type: ignore[attr-defined]

    targets: List[Position] = list(state.crystals)  # type: ignore[attr-defined]
    if need_key:
        targets.extend(state.keys)  # type: ignore[attr-defined]
    targets.append(env.EXIT_TILE)

    cur = state.player  # type: ignore[attr-defined]
    total_dist = 0
    while targets:
        best_idx = min(
            range(len(targets)),
            key=lambda i: env.manhattan_distance(cur, targets[i]),
        )
        total_dist += env.manhattan_distance(cur, targets[best_idx])
        cur = targets.pop(best_idx)

    return total_dist


def greedy_search(
    start_state: Optional[object] = None, max_nodes: Optional[int] = None
) -> Tuple[Optional[List[Direction]], int]:
    env = get_env()
    initial = start_state if start_state is not None else env.create_initial_state()
    counter = 0
    pq: List[Tuple[int, int, object]] = [(greedy_heuristic(initial), counter, initial)]
    visited: Set[object] = {initial}
    parent: Dict[object, Optional[Tuple[object, Direction]]] = {initial: None}
    nodes_explored = 0

    while pq:
        _, _, current = heapq.heappop(pq)
        nodes_explored += 1

        if env.is_goal_state(current):
            return reconstruct_path(current, parent), nodes_explored

        check_limit(nodes_explored, max_nodes)
        if current.status == "lost":  # type: ignore[attr-defined]
            continue

        for direction in env.get_legal_moves(current):
            nxt = env.move_state(current, direction)
            if nxt is None or nxt in visited or nxt.status == "lost":
                continue
            visited.add(nxt)
            parent[nxt] = (current, direction)
            counter += 1
            heapq.heappush(pq, (greedy_heuristic(nxt), counter, nxt))

    return None, nodes_explored
