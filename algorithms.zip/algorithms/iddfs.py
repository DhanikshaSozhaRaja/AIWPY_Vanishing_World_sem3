"""Iterative Deepening Depth-First Search (IDDFS) solver for Vanishing World."""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

from algorithms.common import Direction, check_limit, get_env


def iddfs_search(
    start_state: Optional[object] = None,
    max_nodes: Optional[int] = None,
    max_depth: int = 40,
) -> Tuple[Optional[List[Direction]], int]:
    env = get_env()
    initial = start_state if start_state is not None else env.create_initial_state()
    total_nodes = 0

    for depth_limit in range(max_depth + 1):
        best_depth: Dict[object, int] = {}

        def dls(
            state: object, depth: int, path: List[Direction]
        ) -> Optional[List[Direction]]:
            nonlocal total_nodes
            total_nodes += 1

            if env.is_goal_state(state):
                return path

            check_limit(total_nodes, max_nodes)
            if depth >= depth_limit or state.status == "lost":  # type: ignore[attr-defined]
                return None

            prev_d = best_depth.get(state)
            if prev_d is not None and depth >= prev_d:
                return None
            best_depth[state] = depth

            for direction in env.get_legal_moves(state):
                nxt = env.move_state(state, direction)
                if nxt is None or nxt.status == "lost":
                    continue
                res = dls(nxt, depth + 1, path + [direction])
                if res is not None:
                    return res
            return None

        sol = dls(initial, 0, [])
        if sol is not None:
            return sol, total_nodes

    return None, total_nodes
